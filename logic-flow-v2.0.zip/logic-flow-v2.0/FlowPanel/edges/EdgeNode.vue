<template>
  <div class="edge-node">
    <!-- {{ isHovered }} -->
    <a-popover placement="right" trigger="click" v-model="popVisible">
      <div class="edge-node-btn" @click.stop="changeAddPopover">+</div>
      <template #content>
        <p>执行脚本</p>
        <p>子流程</p>
      </template>
    </a-popover>
  </div>
</template>

<script lang="ts" setup>
  import { ref, onMounted } from 'vue';

  const props = defineProps({
    lf: Object,
    properties: Object,
    id: String,
    isSelected: Boolean,
    isHovered: Boolean,
  });
  // 气泡显隐
  const popVisible = ref(false);

  // 触发气泡
  const changeAddPopover = (e) => {
    popVisible.value = true;
    // this.iconEvent = e
    // this.graphModel.eventCenter.emit(`edge:update-model`, this.model)
  };
  onMounted(() => {
    if (props.lf) {
      props.lf.eventCenter.on('edge:click', () => {
        console.log('edge on LogicFlow instance was clicked');
      });
    }
  });
</script>
<style scoped lang="less">
  .edge-node {
    &-btn {
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      color: #fff;
      font-size: 16px;
      width: 20px;
      height: 20px;
      background: #5865ff;
      border-radius: 50%;
    }
  }
</style>
