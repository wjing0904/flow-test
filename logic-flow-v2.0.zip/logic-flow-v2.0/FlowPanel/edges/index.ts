import { createApp, ref, h } from 'vue';
import { BezierEdge, BezierEdgeModel, h as _h } from '@logicflow/core';

import EdgeNodeComponent from './EdgeNode.vue';

export const NODE_WIDTH = 100; // 节点宽度
export const NODE_HEIGHT = 48; // 节点高度
export const LINE_OFFSET = 24; // 节点高度

const DISTANCE = 12;
const ICON_HEIGHT = 16;
const ICON_WIDTH = 16;
const WORD_HEIGHT = 16;

const DEFAULT_WIDTH = 20;
const DEFAULT_HEIGHT = 20;

class EdgeView extends BezierEdge {
  isMounted: boolean;
  app: any;
  div: any;
  r: any;
  mounted = false;

  constructor(props) {
    super(props);
    this.isMounted = false;
    this.r = h(this.getVueComponent(), { ...this.getVueProps(props) });
    this.app = createApp({
      render: () => this.r,
    });
  }
  getVueComponent() {
    return EdgeNodeComponent;
  }
  getVueProps(props) {
    return {
      properties: props.model.getProperties(),
      isSelected: props.model.isSelected,
      isHovered: props.model.isHovered,
      id: props.model.id,
      lf: props.graphModel,
    };
  }
  shouldUpdate() {
    const data = {
      ...this.props.model.properties,
      isSelected: this.props.model.isSelected,
      isHovered: this.props.model.isHovered,
    };
    if (this.preProperties && this.preProperties === JSON.stringify(data))
      return;
    this.preProperties = JSON.stringify(data);
    return true;
  }

  getText() {
    const { model } = this.props;
    const { customWidth = DEFAULT_WIDTH, customHeight = DEFAULT_HEIGHT } =
      model.getProperties();
    const id = model.id;
    const { startPoint, endPoint } = model;

    const positionData = {
      x: (startPoint.x + endPoint.x - customWidth) / 2,
      y: (startPoint.y + endPoint.y - customHeight) / 2,
      width: customWidth,
      height: customHeight,
    };
    const wrapperStyle = {
      width: customWidth,
      height: customHeight,
    };
    setTimeout(() => {
      const addContainer = document
        .querySelector('#' + 'line_' + id)
        ?.querySelector('.add-wrapper');
      console.log('addContainer', addContainer);
      this.app.mount(addContainer);
    }, 20);
    return _h(
      'foreignObject',
      { ...positionData, id: 'line_' + id, style: `z-index: 20; width: 20px` },
      [
        _h(
          'div',
          {
            style: `display:flex;width: 100%;`,
          },
          [
            _h(
              'div',
              {
                id,
                style: wrapperStyle,
                class: 'add-wrapper',
              },
              [
                _h('span', {
                  id,
                  cl: 'test',
                }),
              ]
            ),
          ]
        ),
      ]
    );
  }
}

class EdgeModel extends BezierEdgeModel {
  setAttributes() {
    this.offset = 20;
    this.isSelected = false;
    this.draggable = false;
    // this.isHitable = false;
  }
  getAnimation() {
    const animation = super.getAnimation();
    animation.stroke = 'blue';
    return animation;
  }
  getEdgeStyle() {
    const style = super.getEdgeStyle();
    const { properties } = this;
    if (properties.isActived) {
      style.strokeDasharray = '4 4';
    }
    style.stroke = '#E1E4FF';
    return style;
  }
  getOutlineStyle() {
    const style = super.getOutlineStyle();
    style.stroke = 'red';
    style.hover.stroke = 'red';
    return style;
  }
}

export default {
  type: 'node-edge',
  view: EdgeView,
  model: EdgeModel,
};
