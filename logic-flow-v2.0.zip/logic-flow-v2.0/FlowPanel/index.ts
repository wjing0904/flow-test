import StartNode from './nodes/StartNode';
import SubNode from './nodes/SubNode';
import EndNode from './nodes/EndNode';
import NodeEdge from './edges/index';
import { ContextPad } from './tools/menu';
import './style.css';

class FlowPanel {
  static pluginName = 'FlowPanel';
  constructor({ lf }) {
    // 开始节点
    lf.register(StartNode);
    // 子节点
    lf.register(SubNode);
    // 节点的边
    lf.register(NodeEdge);
    lf.setDefaultEdgeType('node-edge');
    // 结束节点
    lf.register(EndNode);
    lf.extension.contextPad = new ContextPad({ lf });
  }
  render(lf, domOverlay) {
    lf.extension.contextPad.render(lf, domOverlay);
  }
}

export default FlowPanel;
