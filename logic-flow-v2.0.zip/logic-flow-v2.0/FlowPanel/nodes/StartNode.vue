<!-- 开始节点 -->
<template>
  <div class="start-node">
    <span>{{ text }}</span>
  </div>
</template>

<script lang="ts">
  export default {
    props: {
      properties: Object,
      text: String,
      isSelected: Boolean,
    },
    computed: {
      rowText() {
        if (this.text) {
          return this.text.split(/\n/);
        }
        return [];
      },
    },
  };

</script>
<style scoped lang="less">
  .start-node {
    width: 160px;
    height: 48px;
    text-align: center;
    border-radius: 24px;
    background: #5865ff;
    backdrop-filter: blur(20px);
    span {
      font-size: 16px;
      font-weight: 500;
      line-height: 48px;
      color: #fff;
      text-align: left;
      vertical-align: top;
    }
  }
</style>
