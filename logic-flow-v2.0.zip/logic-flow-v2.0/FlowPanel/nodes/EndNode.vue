<!-- 开始节点 -->
<template>
  <div class="end-node">
    <span>{{ text }}</span>
  </div>
</template>

<script lang="ts">
  export default {
    props: {
      properties: Object,
      text: String,
      isSelected: Boolean,
    },
    computed: {
      rowText() {
        if (this.text) {
          return this.text.split(/\n/);
        }
        return [];
      },
    },
  };
</script>
<style scoped lang="less">
  .end-node {
    width: 160px;
    height: 48px;
    text-align: center;
    line-height: 48px;
    border-radius: 24px;
    background: #eeefff;
    backdrop-filter: blur(20px);
    border: 1px solid #5865ff;

    span {
      font-size: 16px;
      font-weight: 500;
      color: #5865ff;
    }
  }
</style>
