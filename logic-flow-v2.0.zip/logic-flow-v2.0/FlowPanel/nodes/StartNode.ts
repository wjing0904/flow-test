import { HtmlNode, HtmlNodeModel } from '@logicflow/core';
import { createApp, ref, h } from 'vue';
import VueBaseNode from './StartNode.vue';

class StartNodeView extends HtmlNode {
  isMounted: boolean;
  app: any;
  r: any;
  constructor(props) {
    super(props);
    this.isMounted = false;
    console.log('props',props)
    this.r = h(this.getVueComponent(), this.getVueProps(props));
    this.app = createApp({
      render: () => this.r,
    });
  }
  getVueComponent() {
    return VueBaseNode;
  }
  getVueProps(props) {
    return {
      properties: props.model.getProperties(),
      isSelected: props.model.isSelected,
      text: props.model.text.value,
    };
  }
  shouldUpdate() {
    const data = {
      ...this.props.model.properties,
      isSelected: this.props.model.isSelected,
      text: this.props.model.text.value,
    };
    if (this.preProperties && this.preProperties === JSON.stringify(data))
      return;
    this.preProperties = JSON.stringify(data);
    return true;
  }
  setHtml(rootEl) {
    if (!this.isMounted) {
      this.isMounted = true;
      const node = document.createElement('div');
      node.className = 'start-node-wrap';
      node.addEventListener('dblclick', (event) => {
        // this.props.model.setElementState(2)
        // 监听节点双击事件
        // 阻止默认动作
        event.preventDefault();
        // 阻止事件进一步传播
        event.stopPropagation();
      });
      rootEl.appendChild(node);
      this.app.mount(node);
    } else {
      const values = this.getVueProps(this.props);
      Object.keys(values).forEach((key) => {
        this.r.component.props[key] = values[key];
      });
    }
  }
  getText() {
    return null;
  }
}

class StartNodeModel extends HtmlNodeModel {
  initNodeData(data) {
    super.initNodeData(data);
    this.text.editable = false;
  }
  setAttributes() {
    this.width = 160;
    this.height = 48;
  }

  getOutlineStyle() {
    const style = super.getOutlineStyle();
    style.stroke = 'none';
    style.hover.stroke = 'none';
    return style;
  }
  getAnchorStyle(anchorInfo) {
    const style = super.getAnchorStyle(anchorInfo);
    style.stroke = 'none';
    style.fill = 'none';
    return style;
  }
  // getDefaultAnchor() {
  //   return []
  // }
  updateText(value) {
    super.updateText(value);
    this.setAttributes();
  }
}

export default {
  type: 'start-node',
  model: StartNodeModel,
  view: StartNodeView,
};
