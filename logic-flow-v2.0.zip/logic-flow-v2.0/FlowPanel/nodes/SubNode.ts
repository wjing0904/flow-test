/**
 * 子节点为线条样式
 */
import StartNode from './StartNode';
import SubNodeComponent from './SubNode.vue';
import { getTextLengthByCanvas } from '../../util';

class SubNodeView extends StartNode.view {
  getVueComponent() {
    return SubNodeComponent;
  }
  setHtml(rootEl) {
    if (!this.isMounted) {
      this.isMounted = true;
      const node = document.createElement('div');
      node.className = 'sub-node-wrap';
      // node.addEventListener('dblclick', () => {
      //   this.props.model.setElementState(2);
      // });
      rootEl.appendChild(node);
      this.app.mount(node);
    } else {
      const values = this.getVueProps(this.props);
      Object.keys(values).forEach((key) => {
        this.r.component.props[key] = values[key];
      });
    }
  }
}

class SubNodeModel extends StartNode.model {
  initNodeData(data) {
    super.initNodeData(data);
    this.fontSize = 16;
  }
  setAttributes() {
    this.width = 180;
    this.height = 48;
    // if (!this.text.value) {
    //   this.width = 100;
    //   this.height = 40;
    // } else {
    //   const { width, height } = getTextLengthByCanvas(this.text.value, this.fontSize);
    //   this.width = width + 60
    //   this.height = height + 10 + 8
    // }
  }
}

export default {
  type: 'sub-node',
  model: SubNodeModel,
  view: SubNodeView,
};
