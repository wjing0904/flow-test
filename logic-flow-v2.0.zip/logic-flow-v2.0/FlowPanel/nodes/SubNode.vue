<template>
  <div class="sub-node">
    <!-- <component :is="IconSubNode" /> -->
    <IconSubNode />
    <span>{{ text }}</span>
  </div>
</template>

<script lang="ts">
  import { IconSubNode } from '../../images';
  export default {
    props: {
      properties: Object,
      text: String,
      isSelected: Boolean,
    },
    computed: {
      rowText() {
        if (this.text) {
          return this.text.split(/\n/);
        }
        return [];
      },
    },
  };
</script>
<style scoped lang="less">
  .sub-node {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 180px;
    height: 48px;
    border-radius: 8px;
    background: #fff;
    border: 1px solid #5865ff;
    span {
      font-size: 16px;
      color: #0a115f;
    }
  }
</style>
